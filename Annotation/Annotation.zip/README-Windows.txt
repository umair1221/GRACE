Update: force metadata query and ensure boxes never carry over to next image.
